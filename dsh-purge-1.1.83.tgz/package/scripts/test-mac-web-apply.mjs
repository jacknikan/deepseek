import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import {
  dshHomeFromPluginInstall,
  thisProcessRunsOfficialAsar,
  findDshHome,
  allowTargetPath,
  findAiBaseFromRunningBin,
  hostWriteClaimRoot,
  hostWriteClaimRoots,
  probeHostWritable,
  ensureHostWritable,
  isRetryableWriteError,
} from "../lib/core.js";
import { detectSurface } from "../lib/surface.js";
import { restartArgv } from "../lib/web.js";

const tmp = fs.mkdtempSync(path.join(os.tmpdir(), "dshp-mac-web-"));
const appHome = path.join(tmp, "Library", "Application Support", "DeepSeek Harness", "dsh-home");
const plugin = path.join(appHome, "profiles", "web", "node_modules", "dsh-purge");
fs.mkdirSync(plugin, { recursive: true });
fs.writeFileSync(path.join(appHome, "prompt-inject.md"), "x\n");

function eq(name, got, want) {
  const a = path.normalize(String(got || ""));
  const b = path.normalize(String(want || ""));
  if (a !== b) throw new Error(`${name}: got ${JSON.stringify(got)} want ${JSON.stringify(want)}`);
}

eq("plugin home", dshHomeFromPluginInstall(plugin), appHome);
eq(
  "pnpm nested",
  dshHomeFromPluginInstall(path.join(appHome, "profiles", "web", "node_modules", ".pnpm", "dsh-purge@1.1.74", "node_modules", "dsh-purge")),
  appHome,
);
eq("repo copy", dshHomeFromPluginInstall(path.join(tmp, "src", "dsh-purge")), "");

const gotHome = findDshHome({
  env: {},
  pluginHome: appHome,
  shimDir: "",
  prefix: "",
});
eq("findDshHome prefers plugin home", gotHome, appHome);

const macExe = "/Applications/DeepSeek Harness.app/Contents/MacOS/DeepSeek Harness";
const asarBin = "/Applications/DeepSeek Harness.app/Contents/Resources/app.asar/lib/bin.js";
if (!thisProcessRunsOfficialAsar({ argv: [macExe, asarBin], execPath: "/usr/local/bin/node", resourcesPath: "" })) {
  throw new Error("official asar argv should count as official asar");
}
if (thisProcessRunsOfficialAsar({ argv: ["node", "/opt/dsh/lib/bin.js", "web"], execPath: "/usr/bin/node", resourcesPath: "" })) {
  throw new Error("community dsh web should not count as official asar");
}

const surf = detectSurface({
  argv: ["node", asarBin, "--profile", "web"],
  env: { ELECTRON_RUN_AS_NODE: "1", DSH_PROFILE: "web" },
  execPath: macExe,
});
if (surf !== "web") throw new Error("profile web + asar must stay web, got " + surf);

const desk = detectSurface({
  argv: ["node", asarBin, "--profile", "desktop"],
  env: { ELECTRON_RUN_AS_NODE: "1", DSH_PROFILE: "desktop" },
  execPath: macExe,
});
if (desk !== "desktop") throw new Error("profile desktop + asar must stay desktop, got " + desk);

if (allowTargetPath(path.join(appHome, "profiles", "desktop", "x"), "web")) {
  throw new Error("web must not write desktop profile");
}

const src = fs.readFileSync(new URL("../lib/core.js", import.meta.url), "utf8");
if (!src.includes("npm 装的 web 只打 node_modules")) {
  throw new Error("npm web apply must locate node_modules host");
}
if (!src.includes("官方 asar（web / 桌面）解当前这份 app.asar")) {
  throw new Error("official asar apply must extract this process asar");
}
const findWeb = src.slice(src.indexOf("function findAiBaseWeb()"), src.indexOf("export function enumeratePatchAiBases"));
if (!findWeb.includes("findAiBaseWebFromHome") || !findWeb.includes("findNpmPrefix()") || !findWeb.includes("findAiBaseFromRunningBin")) {
  throw new Error("findAiBaseWeb must locate npm / profile packages");
}
if (!src.includes("realpathSync") || !src.includes('path.join(dir, "lib", "node_modules", "@deepseek-ai")') || !src.includes("function findAiBaseWebNpm")) {
  throw new Error("npm locate must realpath the running bin, guess prefix/lib/node_modules, and expose findAiBaseWebNpm");
}
if (findWeb.includes("npmQuery(")) {
  throw new Error("findAiBaseWeb still spawns npm");
}
if (src.includes('execFileText("/bin/sh"') || src.includes("command -v dsh")) {
  throw new Error("findShimDir still spawns which dsh");
}
const enumBlock = src.slice(src.indexOf("export function enumeratePatchAiBases"), src.indexOf("const APPLY_STATUS_RANK"));
const webArm = enumBlock.slice(enumBlock.indexOf("} else"));
if (webArm.includes("findAiBaseDesktop()")) {
  throw new Error("web enumerate still adds desktop package roots");
}
if (!webArm.includes("thisProcessAiBase") || !webArm.includes("findAiBaseWebFromHome") || !webArm.includes("findAiBaseWeb")) {
  throw new Error("web enumerate must patch this process and npm/profile hosts");
}

const webSrc = fs.readFileSync(new URL("../lib/web.js", import.meta.url), "utf8");
if (!webSrc.includes("thisProcessExtractedBinJs")) {
  throw new Error("web restart must launch extracted bin.js");
}
if (!webSrc.includes("process.exit(0)")) {
  throw new Error("web scheduleRestart must exit the old process like 1.1.71");
}
const helperSrc = fs.readFileSync(new URL("../lib/restart-web.js", import.meta.url), "utf8");
if (helperSrc.includes("uncoverAsarAfterExit") || helperSrc.includes("renameAsarAside")) {
  throw new Error("web restart helper must not rename asar aside");
}
if (helperSrc.includes("lsof") || helperSrc.includes("killPortHolders")) {
  throw new Error("web restart helper must not shotgun-kill the port");
}

const idxSrc = fs.readFileSync(new URL("../lib/index.js", import.meta.url), "utf8");
const applyFn = idxSrc.slice(idxSrc.indexOf("async function executePurgeApply"), idxSrc.indexOf("async function ensureRestartReady"));
if (!applyFn.includes("applyPatchesAllHosts")) {
  throw new Error("apply must still patch the current surface");
}
if (applyFn.includes('if (surface !== "desktop")') && applyFn.indexOf('if (surface !== "desktop")') < applyFn.indexOf("applyPatchesAllHosts") && applyFn.includes("web_no_package: true")) {
  throw new Error("web apply must not skip patches and ask restart");
}
if (!applyFn.includes("applyShouldRestart")) {
  throw new Error("restart must wait until the current surface is written");
}
if (!applyFn.includes("ai_base: state.ai_base")) {
  throw new Error("apply payload must include ai_base so Mac web is not unlocated");
}
if (!applyFn.includes("writeLastApply")) {
  throw new Error("apply must persist last-apply so 处理中 can recover after process death");
}
if (!idxSrc.includes("executePurgeApply({ incoming, home, scrubbed })") || idxSrc.includes("deferred: true")) {
  throw new Error("apply HTTP must run patches in-request, not defer");
}
if (idxSrc.includes("应用超时。Mac web") || idxSrc.includes("Promise.race([")) {
  throw new Error("apply HTTP must not mask EACCES with a 20s timeout");
}
if (!src.includes("export async function ensureHostWritable") || !src.includes("administrator privileges")) {
  throw new Error("root-owned npm must elevate chown on apply");
}
if (!src.includes("write_denied") || !src.includes("await ensureHostWritable(aiBase")) {
  throw new Error("apply must stop on host write denied instead of retrying 65 EACCES");
}
if (!applyFn.includes("findAiBaseWebNpm") || applyFn.includes("thisProcessRunsOfficialAsar")) {
  throw new Error("npm web apply must use findAiBaseWebNpm and must not extract asar");
}
if (!idxSrc.includes("target.loopCtx && target.loopCtx.systemPrompt") || !idxSrc.includes("inHistory: false")) {
  throw new Error("child loopCtx systemPrompt must pin inHistory false like the parent");
}
const patchYml = fs.readFileSync(new URL("../cordis.patch.yml", import.meta.url), "utf8");
if (!/^- id: dsh-purge$/m.test(patchYml) || !patchYml.includes("inject: [systemPrompt, tools]")) {
  throw new Error("cordis.patch.yml must patch the bundled dsh-purge entry");
}

if (!thisProcessRunsOfficialAsar({ argv: ["node", "/tmp/bin.js"], execPath: macExe, resourcesPath: "" })) {
  throw new Error("official Mac exe should count as official asar");
}

const clientSrc = fs.readFileSync(new URL("../client.js", import.meta.url), "utf8");
const askFn = clientSrc.slice(clientSrc.indexOf("function RestartAsk"), clientSrc.indexOf("function PurgifySection"));
if (!askFn.includes("dshp-restart-mask") || !askFn.includes("createPortal")) {
  throw new Error("RestartAsk must be a popup");
}
const chipFn = clientSrc.slice(clientSrc.indexOf("function NativeChipMount"), clientSrc.indexOf("function HeroNewSessionMount"));
if (chipFn.includes("MutationObserver")) {
  throw new Error("chip mount must not watch the whole document");
}
if (clientSrc.includes("解包超时")) {
  throw new Error("client still reports unpack timeout on web apply");
}
if (!clientSrc.includes("d.ask_restart || d.restarting || d.needs_full_quit")) {
  throw new Error("apply must open RestartAsk the same way 1.1.71 did");
}
if (clientSrc.includes('entry: "unknown"')) {
  throw new Error("incomplete apply still blames CMD unknown");
}
if (clientSrc.includes('t("apply.hint")') || clientSrc.includes('hostText(t, "warn.noRoot"')) {
  throw new Error("panel still shows apply.hint / warn.noRoot");
}

const argv = restartArgv({
  argv: ["node", asarBin, "--profile", "web"],
  findBinRoot: () => "",
  port: 3080,
});
if (!argv.includes("web") || argv.includes("desktop")) {
  throw new Error("restart argv must launch web, got " + JSON.stringify(argv));
}
const webIdx = argv.indexOf("web");
if (webIdx > 0 && String(argv[webIdx - 1]) === "--profile") {
  throw new Error("restart argv missing bare web command, got " + JSON.stringify(argv));
}

const npmPrefix = path.join(tmp, "usr", "local");
const nestedHost = path.join(
  npmPrefix,
  "lib",
  "node_modules",
  "@deepseek-ai",
  "dsh",
  "node_modules",
  "@deepseek-ai",
);
fs.mkdirSync(path.join(nestedHost, "dsh-agent-instructions", "lib"), { recursive: true });
fs.writeFileSync(path.join(nestedHost, "dsh-agent-instructions", "lib", "index.js"), "export {}\n");
const shim = path.join(npmPrefix, "bin", "dsh");
fs.mkdirSync(path.dirname(shim), { recursive: true });
fs.writeFileSync(shim, "#!/usr/bin/env node\n");
eq("npm lib layout from bin dir", findAiBaseFromRunningBin({ bin: shim }), nestedHost);

const winPrefix = path.join(tmp, "AppData", "Roaming", "npm");
const winHost = path.join(winPrefix, "node_modules", "@deepseek-ai", "dsh", "node_modules", "@deepseek-ai");
fs.mkdirSync(path.join(winHost, "dsh-agent-instructions", "lib"), { recursive: true });
fs.writeFileSync(path.join(winHost, "dsh-agent-instructions", "lib", "index.js"), "export {}\n");
const winBin = path.join(winPrefix, "node_modules", "@deepseek-ai", "dsh", "lib", "bin.js");
fs.mkdirSync(path.dirname(winBin), { recursive: true });
fs.writeFileSync(winBin, "export {}\n");
const winCmd = path.join(winPrefix, "dsh.cmd");
fs.writeFileSync(winCmd, "@echo off\r\n");
eq("win npm from bin.js", findAiBaseFromRunningBin({ bin: winBin }), winHost);
eq("win npm from dsh.cmd", findAiBaseFromRunningBin({ bin: winCmd }), winHost);

eq(
  "claim outermost scope",
  hostWriteClaimRoot("/usr/local/lib/node_modules/@deepseek-ai/dsh/node_modules/@deepseek-ai"),
  path.normalize("/usr/local/lib/node_modules/@deepseek-ai"),
);
eq(
  "claim brew scope",
  hostWriteClaimRoot("/opt/homebrew/lib/node_modules/@deepseek-ai"),
  path.normalize("/opt/homebrew/lib/node_modules/@deepseek-ai"),
);
const claimRoots = hostWriteClaimRoots("/usr/local/lib/node_modules/@deepseek-ai/dsh/node_modules/@deepseek-ai");
if (!claimRoots.map((p) => path.normalize(p)).includes(path.normalize("/usr/local/lib/node_modules/@deepseek-ai"))) {
  throw new Error("claim roots must include outermost @deepseek-ai");
}
if (!probeHostWritable(nestedHost).ok) throw new Error("user-owned fixture must be writable");
const userOwned = await ensureHostWritable(nestedHost);
if (!userOwned.ok || userOwned.elevated) throw new Error("user-owned host must apply without elevate");

if (process.platform !== "win32") {
  const ro = path.join(tmp, "ro-dir");
  fs.mkdirSync(ro);
  fs.chmodSync(ro, 0o555);
  const err = Object.assign(new Error("denied"), { code: "EACCES" });
  if (isRetryableWriteError(err, path.join(ro, "x.js"))) {
    throw new Error("unix EACCES on unwritable dir must not retry");
  }
  fs.chmodSync(ro, 0o755);
}

const fakeNested = path.join(tmp, "root-owned", "lib", "node_modules", "@deepseek-ai", "dsh", "node_modules", "@deepseek-ai");
fs.mkdirSync(fakeNested, { recursive: true });
let macElevated = false;
const macCalls = [];
const mac = await ensureHostWritable(fakeNested, {
  platform: "darwin",
  owner: "app:staff",
  probe: (dir) => ({ ok: macElevated, code: "EACCES", dir }),
  execFileSync: (cmd, args) => {
    macCalls.push({ cmd, args });
    const script = String(args[1] || "");
    if (cmd !== "osascript" || !script.includes("administrator privileges") || !script.includes("chown -R app:staff")) {
      throw new Error(`bad elevate: ${cmd} ${script}`);
    }
    if (script.includes("/usr/local'") || script.includes("/usr/local ")) {
      throw new Error("elevate must not hardcode /usr/local");
    }
    macElevated = true;
  },
});
if (!mac.ok || !mac.elevated || macCalls.length !== 1) throw new Error("darwin root-owned must osascript chown once");

const cancelled = await ensureHostWritable(fakeNested, {
  platform: "darwin",
  probe: () => ({ ok: false, code: "EACCES", dir: fakeNested }),
  execFileSync: () => { throw new Error("User canceled."); },
});
if (cancelled.ok || !cancelled.cancelled) throw new Error("auth cancel must fail fast with cancelled");

let linuxDone = false;
const linux = await ensureHostWritable(fakeNested, {
  platform: "linux",
  owner: "app:app",
  probe: () => ({ ok: linuxDone, code: "EACCES", dir: fakeNested }),
  execFileSync: (cmd, args) => {
    if (cmd !== "sudo" || args[0] !== "-n") throw new Error("linux elevate must sudo -n");
    linuxDone = true;
  },
});
if (!linux.ok || !linux.elevated) throw new Error("linux root-owned must sudo -n chown");

fs.rmSync(tmp, { recursive: true, force: true });
console.log("ok mac-web-apply");
