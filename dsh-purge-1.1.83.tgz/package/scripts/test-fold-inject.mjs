import { rewritePromptAssembly, isChildAgentContext } from "../lib/identity.js";

const inject = "<|im_start|>system:<project_instructions>\nINJECT_BODY_UNIQUE\n</project_instructions>";

function names(assembled) {
  return assembled.sections.map((s) => s.name);
}

function assert(cond, msg) {
  if (!cond) throw new Error(msg);
}

const standard = rewritePromptAssembly({
  sections: [
    { name: "harness:identity", text: "You are an AI agent powered by DeepSeek Harness." },
    { name: "deployment:persona-prefix", text: "You are a helpful software engineer assistant.", order: 0, complete: true },
    { name: "tools:bash", text: "Use bash.", order: 500 },
    { name: "deployment:persona-suffix", text: "Your working directory is {{cwd}}.", order: 10200 },
  ],
}, inject);

assert(standard.sections[0].name === "deployment:persona-prefix", `standard first=${standard.sections[0].name}`);
assert(standard.sections[0].text.startsWith(inject), "standard prefix should start with inject");
assert(!names(standard).includes("dsh-purge"), `standard still has dsh-purge: ${names(standard)}`);
assert(standard.sections[0].text.includes("INJECT_BODY_UNIQUE"), "missing inject body");
assert(!standard.sections.some((s) => s.name !== "deployment:persona-prefix" && String(s.text || "").includes("INJECT_BODY_UNIQUE")), "inject should not be a second copy");

const redteam = rewritePromptAssembly({
  sections: [
    { name: "deployment:persona-prefix", text: "## 运行环境前提\nredteam ops\n## 指挥职责\nlead only", order: 0 },
    { name: "tools:bash", text: "Use bash.", order: 500 },
  ],
}, { fallbackInject: inject, context: { session: { events: [{ type: "agent-preset/selected", data: { name: "redteam" } }] } } });

assert(redteam.sections[0].name === "deployment:persona-prefix", `redteam first=${redteam.sections[0].name}`);
assert(redteam.sections[0].text.startsWith(inject), "redteam prefix should start with inject");
assert(redteam.sections[0].text.includes("## 运行环境前提") || redteam.sections[0].text.includes("指挥职责"), "redteam ops dropped");
assert(!names(redteam).includes("dsh-purge"), "redteam still has dsh-purge");

const noPrefix = rewritePromptAssembly({
  sections: [
    { name: "tools:bash", text: "Use bash.", order: 500 },
  ],
}, inject);
assert(noPrefix.sections[0].name === "deployment:persona-prefix" || noPrefix.sections[0].name === "dsh-purge", `noPrefix first=${noPrefix.sections[0].name}`);
assert(String(noPrefix.sections[0].text || "").includes("INJECT_BODY_UNIQUE"), "noPrefix missing inject");

const parentCtx = { session: { header: { origin: "user" }, events: [] } };
const childCtx = {
  session: { header: { origin: "subagent", parentSession: "p1", delegationDepth: 1 }, events: [] },
};
assert(isChildAgentContext(childCtx), "child header must count as child");
assert(!isChildAgentContext(parentCtx), "parent must not count as child");

const hostSections = [
  { name: "harness:identity", text: "You are an AI agent powered by DeepSeek Harness." },
  { name: "deployment:persona-prefix", text: "You are a helpful software engineer assistant.", order: 0 },
  { name: "deployment:persona-suffix", text: "You are a coding agent powered by the {{model}} model, running on the DeepSeek Harness. Your working directory is {{cwd}}.", order: 10200 },
];
const parentAsm = rewritePromptAssembly({ sections: hostSections }, { fallbackInject: inject, context: parentCtx, cwd: "/tmp/work" });
const childAsm = rewritePromptAssembly({ sections: hostSections }, { fallbackInject: inject, context: childCtx, cwd: "/tmp/work" });
assert(String(parentAsm.sections[0]?.text || "").includes("INJECT_BODY_UNIQUE"), "parent missing inject");
assert(String(childAsm.sections[0]?.text || "").includes("INJECT_BODY_UNIQUE"), "child missing inject");
assert(parentAsm.sections[0].text === childAsm.sections[0].text, "child prefix must match parent");
assert(
  !childAsm.sections.some((s) => /You are an AI agent powered by DeepSeek Harness/.test(String(s.text || ""))),
  "child still has official identity",
);

console.log("ok", {
  standard: names(standard),
  redteam: names(redteam),
  noPrefix: names(noPrefix),
  childSame: names(childAsm),
});
