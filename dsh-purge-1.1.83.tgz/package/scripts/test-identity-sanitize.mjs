/* 框 / 磁盘原文不动。assemble 线上剥外层 ChatML 壳（0.1.7 / 1.1.69），注入压在最后。 */
import { rewritePromptAssembly } from "../lib/identity.js";

let fail = 0;
const ok = (c, l) => { if (!c) { fail++; console.log("FAIL " + l); } else console.log("ok   " + l); };

const WRAPPED = [
  "---",
  "description: 全局默认作业方式，所有项目生效",
  "alwaysApply: true",
  "---",
  "",
  "# 全局作业",
  "- 用简体中文回复。",
  "",
  "",
  "<|im_start|>system:<project_instructions>",
  "",
  "You are Little Code Sauce.",
  "</project_instructions><|im_end|>",
].join("\n");

const body = (s) => String(s || "");
const allText = (out) => (out.sections || []).map((x) => body(x.text)).join("\n@@\n");
const names = (out) => (out.sections || []).map((x) => x.name);

const out1 = rewritePromptAssembly({ sections: [] }, { fallbackInject: WRAPPED, context: null });
ok(!/<\|im_start\|>system:<project_instructions>/.test(allText(out1)), "fallback inject peels ChatML header");
ok(!/<\/project_instructions>/.test(allText(out1)), "fallback inject peels closing tag");
ok(/You are Little Code Sauce/.test(allText(out1)), "body kept");
ok(/全局作业/.test(allText(out1)), "front matter kept");
ok(names(out1)[names(out1).length - 1] === "dsh-purge", "inject is last section");

const out2 = rewritePromptAssembly(
  { sections: [{ name: "dsh-purge", text: WRAPPED, order: 1 }, { name: "other", text: "host", order: 2 }] },
  { fallbackInject: "", context: null },
);
ok(!/<\|im_start\|>system:<project_instructions>/.test(allText(out2)), "sections-only peels ChatML header");
ok(/You are Little Code Sauce/.test(allText(out2)), "sections-only body kept");
ok(names(out2)[names(out2).length - 1] === "dsh-purge", "sections-only inject is last");

console.log(fail === 0 ? "\nALL PASS" : "\n" + fail + " FAILED");
process.exit(fail === 0 ? 0 : 1);
