# 贡献名单

从 Git 提交记录统计（截止换证时）。人数是提交次数，不是股份。

**维护者（同一人，两个提交名）：**

| 提交名 | 邮箱 | 提交数 |
| --- | --- | ---: |
| 叫我小杨同学 | a2269198325@163.com | 264 |
| yang | a2269198325@163.com | 42 |

**外部贡献者（MIT 时期合入的补丁）：**

| 提交名 | 邮箱 | 提交数 | 主要改动 |
| --- | --- | ---: | --- |
| Musan / Musan-34 | 279201993+Musan-34@users.noreply.github.com | 6 | #1/#2/#3 skipIfMarked；超时补丁幂等 |
| fomaper | 38674512+fomaper@users.noreply.github.com | 3 | 桌面重启 inflight、client 超时、启动不扫 $HOME |
| Gaizka | 1058674225@qq.com | 2 | Electron 跳过 child_process ESM 重定向 |
| zksnet | wangyangv1@gmail.com | 2 | Bash 前台等待 |
| Tofu / 鼬豆腐GOLDkey | 178003727+Tofu707@users.noreply.github.com | 2 | 不改 pnpm-lock；v4 producer-owned source |
| 21hbguo | 139569698+21hbguo@users.noreply.github.com | 1 | assemble 守卫幂等 |
| Cracer | 46320829+cracer4869@users.noreply.github.com | 1 | permissionPresetsOf 未 inject |
| TLcm | 1743533263@qq.com | 1 | 早期补丁升级 |
| fqscfqj | fqscfqj@outlook.com | 1 | SCOPE_INTRO 非幂等 |
| qianxuno | 179305118+qianxuno@users.noreply.github.com | 1 | escalation / desktop-shell 锚点 |
| wangqiupei | 154594742@qq.com | 1 | Desktop 解包路径探测 |

换证说明：这些人当时是按 MIT 把补丁合进来的。MIT 允许再许可分发。**当前发行包走商业许可**；他们自己的旧提交、以及换证前的 Git tag，仍可按 MIT 使用。没有 CLA，所以这不是「所有历史版权都转让给维护者」。2026年10月27日起仓库闭源，新版本只在 https://t.me/LLM_PoJia/271 发。
