# 先读这里

我被裁了，没有稳定收入。仓库要闭源，新版本改到频道发。

**2026年10月26日前：** 有话请写在 [Issue #130](https://github.com/YuJunZhiXue/dsh-purge/issues/130)。这七天是征集，不是招功能 PR。

**2026年10月27日起：** 本仓库闭源，不再收 PR。后续版本只在 https://t.me/LLM_PoJia/271 。

许可是商业许可，见 [LICENSE](./LICENSE)。旧 MIT tag 仍按 MIT。
